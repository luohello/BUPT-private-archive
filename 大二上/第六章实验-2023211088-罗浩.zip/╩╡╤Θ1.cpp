#include<bits/stdc++.h>
#define maxn 1000
#define INF 0x3f3f3f3f
#define ll long long
#define mem(a,b) memset(a,b,sizeof(a))
using namespace std;
typedef struct node{
    char data;
    struct node *lc,*rc;
}Treenode,*Tree;
char s[maxn];
int p=0;
void build(Tree root)
{
    if(s[p]==0)
    return;
    root->data=s[p];
    root->lc=root->rc=NULL;
    if(s[++p]!='*'&&s[p]!=0)
    {
        Tree ls=(Tree)malloc(sizeof(Treenode));
        root->lc=ls;
        build(root->lc);
    }
    if(s[++p]!='*'&&s[p]!=0)
    {
        Tree rs=(Tree)malloc(sizeof(Treenode));
        root->rc=rs;
        build(root->rc);
    }
}
void print_bitree(Tree r)
{
    if(r==NULL||r->data=='*')
    return;
    printf("%c(",r->data);
    print_bitree(r->lc);
    printf(",");
    print_bitree(r->rc);
    printf(")");
}
int main()
{
    Tree h=(Tree)malloc(sizeof(Treenode));
    scanf("%s",&s);
    build(h);
    print_bitree(h);
    system("pause");
}
/*
abdhi****e**cf**g**
a**
*
abc**d**e**
*/