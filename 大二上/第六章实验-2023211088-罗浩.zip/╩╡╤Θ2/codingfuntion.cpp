#include<bits/stdc++.h>
#include<cstdio>
#include<string.h>
#define maxn 1000
#define INF 0x3f3f3f3f
#define ll long long
#define mem(a,b) memset(a,b,sizeof(a))
using namespace std;
char s[maxn];
struct hfmnode{
    int cnt=0;
    char nc[50];
    int lc,rc,parent;
}ocode[maxn];
char Stack[maxn];
void select(int fa,hfmnode*p)
{
    hfmnode a,b;
    int w=INF,ptr=0;
    for(int i=0;i<fa;i++)
    if(p[i].parent==-1&&w>p[i].cnt)
    {
        w=p[i].cnt;
        ptr=i;
    }
    a=p[ptr];
    p[ptr].parent=fa;
    p[fa].lc=ptr;
    w=INF;
    for(int i=0;i<fa;i++)
    if(p[i].parent==-1&&w>p[i].cnt)
    {
        w=p[i].cnt;
        ptr=i;
    }
    b=p[ptr];
    p[ptr].parent=fa;
    p[fa].rc=ptr;

    p[fa].cnt=a.cnt+b.cnt;
}
void coding(int stackptr,int treeptr)
{
    if(ocode[treeptr].lc==-1)
    {
        Stack[stackptr+1]=0;
        strcpy(ocode[treeptr].nc,Stack);
        return;
    }
    Stack[stackptr+1]='1';
    coding(stackptr+1,ocode[treeptr].lc);
    Stack[stackptr+1]='0';
    coding(stackptr+1,ocode[treeptr].rc);
}
void build(void)
{

    for(int i=256;i<=510;i++)
    {
        select(i,ocode);
    }//最后一个节点一定是根节点
    coding(-1,510);
}
void print_binary(int freq,FILE*file)
{
    int p=8;
    while(p--)
    {
        fprintf(file,"%d",freq&1);
        freq>>=1;
    }
}
int main()
{
    FILE* f=fopen(".\\originaltext.txt","r");
    if(f==NULL)
    {
        printf("opening failed!!");
        return 0;
    }
    for(int i=0;i<=511;i++)
    {
        ocode[i].parent=-1;
        ocode[i].lc=ocode[i].rc=-1;
    }
    while(fgets(s,1024,f))
    {
        int len=strlen(s);
        for(int i=0;i<len;i++)
        ocode[s[i]].cnt++;
    }//进行统计
    build();
    fseek(f,0,SEEK_SET);
    FILE*fp=fopen(".\\codedword.txt","w");
    if(fp==NULL)
    {
        printf("opening failed!!");
        return 0;
    }
    for(int i=0;i<=255;i++)
    {
        print_binary(ocode[i].cnt,fp);
    }//打印译码表
    while(fgets(s,1024,f))
    {
        int len=strlen(s);
        for(int i=0;i<len;i++)
        fprintf(fp,"%s",ocode[s[i]].nc);
    }
    fclose(f);
    fclose(fp);
}