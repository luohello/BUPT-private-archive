#include<bits/stdc++.h>
#include<cstdio>
#include<string.h>
#define maxn 1000
#define INF 0x3f3f3f3f
#define ll long long
#define mem(a,b) memset(a,b,sizeof(a))
using namespace std;
struct hfmnode{
    int cnt=0;
    char nc[50];
    int lc,rc,parent;
}ocode[maxn];
char Stack[maxn];
void input_binary(int p,FILE* file)
{
    char buf[maxn];
    fscanf(file,"%8s",buf);
    int weight=0,base=1;
    for(int i=0;i<8;i++,base*=2)
    {
        weight+=base*(buf[i]-'0');
    }
    ocode[p].cnt=weight;
}
void select(int fa,hfmnode*p)
{
    hfmnode a,b;
    int w=INF,ptr=0;
    for(int i=0;i<fa;i++)
    if(p[i].parent==-1&&w>p[i].cnt)
    {
        w=p[i].cnt;
        ptr=i;
    }
    a=p[ptr];
    p[ptr].parent=fa;
    p[fa].lc=ptr;
    w=INF;
    for(int i=0;i<fa;i++)
    if(p[i].parent==-1&&w>p[i].cnt)
    {
        w=p[i].cnt;
        ptr=i;
    }
    b=p[ptr];
    p[ptr].parent=fa;
    p[fa].rc=ptr;

    p[fa].cnt=a.cnt+b.cnt;
}
void coding(int stackptr,int treeptr)
{
    if(ocode[treeptr].lc==-1)
    {
        Stack[stackptr+1]=0;
        strcpy(ocode[treeptr].nc,Stack);
        return;
    }
    Stack[stackptr+1]='1';
    coding(stackptr+1,ocode[treeptr].lc);
    Stack[stackptr+1]='0';
    coding(stackptr+1,ocode[treeptr].rc);
}
void build(void)
{

    for(int i=256;i<=510;i++)
    {
        select(i,ocode);
    }//最后一个节点一定是根节点
    coding(-1,510);
}
void decoding(FILE*file)
{
    char ch;
    int ptr=510;
    FILE*ans=fopen(".\\decodeword.txt","w");
    while(~(ch=fgetc(file)))
    {
        if(ptr>=256)
        {
            if(ch=='1')ptr=ocode[ptr].lc;
            else ptr=ocode[ptr].rc;
        }
        if(ptr<256)
        {
            char tem=ptr;
            fprintf(ans,"%c",tem);
            ptr=510;
        }
    }
    fclose(ans);
}
int main()
{
    FILE*fp=fopen(".\\codedword.txt","r");
    if(fp==NULL)
    {
        printf("opening failed!!");
        return 0;
    }
    for(int i=0;i<=511;i++)
    {
        ocode[i].parent=-1;
        ocode[i].lc=ocode[i].rc=-1;
    }
    for(int i=0;i<=255;i++)
    {
        input_binary(i,fp);
    }
    build();
    decoding(fp);
    fclose(fp);
}