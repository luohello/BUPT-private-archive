#include<bits/stdc++.h>
#include<stdlib.h>
#include<time.h>
#define maxn 50
#define INF 0x3f3f3f3f
#define ll long long
#define mem(a,b) memset(a,b,sizeof(a))
using namespace std;
void generate_matrix(int v,int e,int g[][maxn])
{
    int num=0;
    srand(time(0));
    while(num<e)
    {
        int i=rand()%v+1;
        int j=rand()%v+1;
        if(!g[i][j]&&!g[j][i]&&(i!=j))
        {
            g[i][j]=1;
            num++;
        }
    }
}
void print_matrix(int g[][maxn],int v)
{
    for(int i=1;i<=v;i++)
    {
        int j=1;
        for(;j<v;j++)
        printf("%d ",g[i][j]);
        printf("%d\n",g[i][j]);
    }
}
bool valid(int v,int e)
{
    if(e>(v-1)*v/2)
    {
        printf("Invalid, edges too much!!\n");
        return false;
    }
    if(v<=1||e<0)
    {
        printf("Invalid, please input positive integer above 1!!\n");
        return false;
    }
    if(v>=maxn)
    {
        printf("Invalid, v too big, a bit overwhelming!!\n");
        return false;
    }
    return true;
}
void generate_transitive_closure(int g[][maxn],int v)
{
    for(int k=1;k<=v;k++)
        for(int i=1;i<=v;i++)
            for(int j=1;j<=v;j++)
            g[i][j]=g[i][j]|(g[i][k]&g[k][j]);
}
void reachable_dots(int g[][maxn],int v)
{
    int tot=0;
    for(int i=1;i<=v;i++)
    for(int j=1;j<=v;j++)
    if(g[i][j])tot++;
    double ans=(double)tot/v;
    printf("average number of vertices that could be reached:\n");
    printf("%.2lf\n",ans);
}
int main()
{
    int v,e;
    while(1)
    {
        char ch;
        printf("Input designated vertices,edges\n");
        scanf("%d%d",&v,&e);
        int graph[maxn][maxn];
        mem(graph,0);
        if(valid(v,e))
        {
            generate_matrix(v,e,graph);
            printf("random directed graph generated as below:\n");
            print_matrix(graph,v);
            generate_transitive_closure(graph,v);
            printf("vertices that could be reached\n");
            print_matrix(graph,v);
            reachable_dots(graph,v);
        }
        getchar();
        printf("would you like to go on?(any letter or n):");
        ch=getchar();
        if(ch=='n')
        break;
    }
}