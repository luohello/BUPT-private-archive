#include<bits/stdc++.h>
#define maxn 10000
#define ll long long
using namespace std;
typedef struct node{
    int data;
    struct node*next;
}linknode,*link;
link Create_list(void)
{
    link headptr=NULL,currentptr=NULL,lastptr=NULL;
    int temp;
    scanf("%d",&temp);
    while(temp!=-1)
    {
        currentptr=(link)malloc(sizeof(linknode));
        if(currentptr!=NULL)
        {
            currentptr->data=temp;
            if(headptr==NULL)
            {
                headptr=currentptr;
                lastptr=currentptr;
            }
            else
            {
                lastptr->next=currentptr;
                lastptr=currentptr;
            }
        }
        scanf("%d",&temp);
    }
    lastptr->next=NULL;
    link head=(link)malloc(sizeof(linknode));
    head->next=headptr;
    return head;
}
link Union(link la,link lb)
{
    //采取先归并后头插的思路
    link pa=la->next,pb=lb->next,lastptr=la,headptr=la;
    while(pa!=NULL&&pb!=NULL)
    {
        if(pa->data<=pb->data)
        lastptr->next=pa,lastptr=pa,pa=pa->next;
        else
        lastptr->next=pb,lastptr=pb,pb=pb->next;
    }
    if(pa==NULL)
    lastptr->next=pb;
    else
    lastptr->next=pa;
    free(lb);


    link ptr=headptr->next;
    headptr->next=NULL;
    while(ptr!=NULL)
    {
        lastptr=ptr;
        ptr=ptr->next;
        lastptr->next=headptr->next;
        headptr->next=lastptr;
    }
    return headptr;
}
void Printlist(link ptr)
{
    link currentptr=ptr->next;
    while(currentptr->next!=NULL)
    {
        printf("%d ",currentptr->data);
        currentptr=currentptr->next;
    }
    printf("%d\n",currentptr->data);
}
int main()
{
    link a,b,c;
    a=Create_list();
    b=Create_list();
    c=Union(a,b);
    Printlist(c);
    system("pause");
}