#include<bits/stdc++.h>
#define maxn 10000
#define ll long long
using namespace std;
typedef struct node{
    int data;
    struct node*next;
}linknode,*link;
link Create_list(void)
{
    link headptr=NULL,currentptr=NULL,lastptr=NULL;
    int temp;
    scanf("%d",&temp);
    while(temp!=-1)
    {
        currentptr=(link)malloc(sizeof(linknode));
        if(currentptr!=NULL)
        {
            currentptr->data=temp;
            if(headptr==NULL)
            {
                headptr=currentptr;
                lastptr=currentptr;
            }
            else
            {
                lastptr->next=currentptr;
                lastptr=currentptr;
            }
        }
        scanf("%d",&temp);
    }
    lastptr->next=NULL;
    return headptr;
}
void Printlist(link ptr)
{
    link currentptr=ptr;
    while(currentptr->next!=NULL)
    {
        printf("%d ",currentptr->data);
        currentptr=currentptr->next;
    }
    printf("%d\n",currentptr->data);
}
link LinkListSort(link list)
{
    int listlen=0;
    link ptr=list,lastptr,headptr;
    headptr=lastptr=(link)malloc(sizeof(linknode));
    lastptr->next=list;
    while(ptr)
    listlen++,ptr=ptr->next;
    while(listlen--)
    {   
        ptr=headptr->next,lastptr=headptr;
        while(ptr->next!=NULL)
        {
            if(ptr->next->data<ptr->data)
            {
                link temptr;
                lastptr->next=ptr->next;
                temptr=ptr->next->next;
                ptr->next->next=ptr;
                ptr->next=temptr;
                lastptr=lastptr->next;
            }
            else
            {
                ptr=ptr->next;
                lastptr=lastptr->next;
            }
        }
    }
    list=headptr->next;
    free(headptr);
    return list;
}
int main()
{
    link a,b,c;
    a=Create_list();
    c=LinkListSort(a);
    Printlist(c);
    system("pause");
}