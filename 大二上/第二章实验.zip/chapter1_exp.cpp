#include<bits/stdc++.h>
#define maxn 10000
#define ll long long
#define INF 0x3f3f3f3f
#define mem(a,b) memset(a,b,sizeof(a))
using namespace std;
typedef struct node{
    int id;
    struct node *next;
}linknode,*link;
link Create_loop_list(int n)
{
    link headptr=NULL,cur=NULL,last=NULL;
    for(int i=1;i<=n;i++)
    {
        cur=(link)malloc(sizeof(linknode));
        if(cur)
        {
            cur->id=i;
            if(!headptr)
            {
                headptr=cur;
                last=cur;
            }
            else
            {
                last->next=cur;
                last=cur;
            }
        }
    }
    last->next=headptr;
    return last;
}
int check(int n,int x,int y)
{
    link headptr,ptr,lastptr,tem;
    headptr=Create_loop_list(n);
    lastptr=headptr;
    ptr=headptr->next;
    while(ptr->id!=x)
    {
        lastptr=ptr;
        ptr=ptr->next;
    }
    while(ptr->next!=ptr)
    {
        for(int i=1;i<y;i++)
        {
            lastptr=ptr;
            ptr=ptr->next;
        }
        lastptr->next=ptr->next;
        tem=ptr;
        ptr=ptr->next;
        free(tem);
    }
    if(ptr->id==1)
    {
        free(ptr);
        return 1;
    }
    else
    {
        free(ptr);
        return 0;
    }
}
int main()
{
    int n,x,y;
    while(1)
    {
        printf("Input the fixed value: (x/y/n,press 'q' to exit)");
        char opt[2];
        scanf("%s",opt);
        if(opt[0]=='q')
        break;
        if(opt[0]=='n')
        {
            printf("value: ");
            scanf("%d",&n);
            if(n>=1)
            {  
                printf("x,y\n");
                for(int i=1;i<=n;i++)
                for(int j=1;j<=n*2;j++)
                if(check(n,i,j))
                printf("%d,%d\n",i,j);
            }
            else
            puts("Invalid Input!!");
        }
        else if(opt[0]=='x')
        {
            printf("value: ");
            scanf("%d",&x);
            if(x>=1)
            {  
                printf("n,y\n");
                for(int i=x;i<=x*5;i++)//总人数
                for(int j=1;j<=i+1;j++)//数数计数
                if(check(i,x,j))
                printf("%d,%d\n",i,j);
            }
            else
            puts("Invalid Input!!");
        }
        else if(opt[0]=='y')
        {
            printf("value: ");
            scanf("%d",&y);
            if(y>=1)
            {  
                printf("n,x\n");
                for(int i=y;i<=y*5;i++)//总人数
                for(int j=1;j<=i;j++)//从第j个人开始
                if(check(i,j,y))
                printf("%d,%d\n",i,j);
            }
            else
            puts("Invalid Input!!");
        }
        else
        puts("Invalid Input!!");
    }
    system("pause");
}