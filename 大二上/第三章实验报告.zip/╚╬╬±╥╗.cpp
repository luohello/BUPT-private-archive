#include<bits/stdc++.h>
#define maxn 10000
#define INF 0x3f3f3f3f
#define ll long long
#define mem(a,b) memset(a,b,sizeof(a))
using namespace std;
char str[maxn];
struct node{
    char sta[maxn];
    int top;
}OPRT,TOT;
void init_stack(node &a)
{
    a.top=0;
}
void push(node &a,char ch)
{
    a.sta[++a.top]=ch;
}
void print_stack(node a)
{
    while(a.top>=0)
    printf("%c",a.sta[a.top--]);
}
void pop(node &a)
{
    a.top--;
}
void bracket_match(void)
{
    init_stack(OPRT),init_stack(TOT);
    int len=strlen(str+1);
    push(OPRT,'#');
    int optnum=0,bracknum=0;
    for(int i=len;i>=1;i--)
    {
        push(TOT,str[i]);
        if(str[i]==')')
        bracknum++,push(OPRT,str[i]);
        if(str[i]>='0'&&str[i]<='9')
        while(str[i-1]>='0'&&str[i-1]<='9')
        i--,push(TOT,str[i]);
        if(str[i]=='+'||str[i]=='-')
        optnum++,push(OPRT,str[i]);
        int tem=optnum;
        while(bracknum&&tem)
        {
            if(str[i]>='0'&&str[i]<='9'&&OPRT.sta[OPRT.top]!=')')
            push(TOT,'('),bracknum--,tem--;
            else break;
        }
        if(str[i]>='0'&&str[i]<='9'&&OPRT.sta[OPRT.top]!=')')
        pop(OPRT);
    }
    while(bracknum--)
    push(TOT,'(');
}
int main()
{
    scanf("%s",str+1);
    bracket_match();
    print_stack(TOT);
    system("pause");
}
//test:1-2)*3-4)*5-6)))
//test2:1+2-3)/5-6+1)
//test3:1+256)*56-9)+8*9-69)+5)*6