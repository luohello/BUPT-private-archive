#include<bits/stdc++.h>
#define maxn 10000
#define INF 0x3f3f3f3f
#define ll long long
#define mem(a,b) memset(a,b,sizeof(a))
using  namespace std;
struct Sstack{
    int a[maxn];
    int top;
};
typedef struct node{
    char val;
    struct node*next;
}*link,linknode;
struct Queue{
    link headptr;
    link tailptr;
};
void init_stack(Sstack &p){
    p.top=0;
    mem(p.a,0);
}
void push(Sstack &p, char ch){
    p.a[++p.top]=ch;
}
char pop(Sstack &m){
    return m.a[m.top--];
}
int empty(Sstack &m){
    return m.top<=0;
}
void pushback(Queue &m,char ch)
{
    if(m.tailptr==NULL)
    {
        m.tailptr=(link)malloc(sizeof(linknode));
        m.tailptr->val=ch;
        m.tailptr->next=NULL;
        m.headptr=m.tailptr;
        return;
    }
    m.tailptr->next=(link)malloc(sizeof(linknode));
    m.tailptr=m.tailptr->next;
    m.tailptr->val=ch;
    m.tailptr->next=NULL;
}
char pop_queue(Queue &m)
{
    char ans;
    link lastptr=m.headptr;
    if(m.headptr->next==NULL)
    m.headptr=m.tailptr=NULL;
    else
    m.headptr=m.headptr->next;
    ans=lastptr->val;
    free(lastptr);
    return ans;
}
int judge(const char *s)
{
    int len=strlen(s);
    Queue q={NULL,NULL};
    Sstack sta;
    init_stack(sta);
    for(int i=0;i<len-1;i++)
    pushback(q,s[i]),push(sta,s[i]);
    while(!empty(sta))
    if(pop(sta)!=pop_queue(q))
    return 0;
    return 1;
}
int main()
{
    while(1)
    {
        char str[maxn];
        printf("please enter the string you want(q to quit):\n");
        scanf("%s",str);
        int len=strlen(str);
        if(str[0]=='q')
        break;
        if(str[len-1]!='#')
        {printf("invalid input!! please try again\n");
        continue;}
        if(judge(str))
        printf("Yes\n");
        else
        printf("No\n");
    }
    system("pause");
}