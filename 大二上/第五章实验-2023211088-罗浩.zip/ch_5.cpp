#include<bits/stdc++.h>
#define maxn 10000
#define INF 0x3f3f3f3f
#define ll long long
using namespace std;
struct tup{
    int i,j,v;
};
struct sprmat{
    int n,m,t=0;
    tup data[maxn];    
};
void init(sprmat &p)
{
    p.m=p.n=p.t=0;
    memset(p.data,0,sizeof(p.data));
}
int query(int i,int j,sprmat p)
{
    for(int k=1;k<=p.t;k++)
    if(p.data[k].i==i&&p.data[k].j==j)
    return p.data[k].v;
    return 0;
}
int mul(sprmat &a,sprmat &b,sprmat &c)
{
    init(c);
    if(a.m!=b.n)
    return false;
    for(int i=1;i<=a.n;i++)
    for(int j=1;j<=b.m;j++)
    {
        int sum=0;
        for(int k=1;k<=a.m;k++)
        sum+=query(i,k,a)*query(k,j,b);
        if(sum)
        c.data[++c.t].v=sum,c.data[c.t].i=i,c.data[c.t].j=j;
    }
    c.n=a.n,c.m=b.m;
    return true;
}
int add(sprmat &a,sprmat &b,sprmat &c)
{
    init(c);
    if(a.m!=b.m||a.n!=b.n)
    return false;
    for(int i=1;i<=a.n;i++)
    for(int j=1;j<=a.m;j++)
    {
        int sum;
        sum=query(i,j,a)+query(i,j,b);
        if(sum)
        c.data[++c.t].v=sum,c.data[c.t].i=i,c.data[c.t].j=j;
    }
    c.n=a.n,c.m=a.m;
    return true;
}
void printmat(sprmat p)
{
    printf("The triple:\n");
    for(int k=1;k<=p.t;k++)
    printf("%d %d %d\n",p.data[k].i,p.data[k].j,p.data[k].v);
    printf("The matrix:\n");
    for(int i=1;i<=p.n;i++)
    {
        for(int j=1;j<=p.m;j++)
        printf("%d ",query(i,j,p));
        puts("");
    }
}
int main()
{
    sprmat A,B;
    printf("Please input the first Matrix: \n(first with line and column: )\n");
    scanf("%d%d",&A.n,&A.m);
    printf("then with the matrix:(space to indicate single elem):\n");
    for(int i=1;i<=A.n;i++)
    for(int j=1;j<=A.m;j++)
    {
        int val;
        scanf("%d",&val);
        if(val!=0)
        A.data[++A.t].v=val,A.data[A.t].i=i,A.data[A.t].j=j;
    }
    printf("Please input the second Matrix: \n(first with line and column: )\n");
    scanf("%d%d",&B.n,&B.m);
    printf("then with the matrix:(space to indicate single elem):\n");
    for(int i=1;i<=B.n;i++)
    for(int j=1;j<=B.m;j++)
    {
        int val;
        scanf("%d",&val);
        if(val!=0)
        B.data[++B.t].v=val,B.data[B.t].i=i,B.data[B.t].j=j;
    }
    while(1)
    {
        getchar();
        printf("1or2 to operate multiplication or addition(q to quit):\n");
        char ch;
        sprmat C;
        ch=getchar();
        if(ch=='q')
        break;
        else if(ch=='1')
        {
            if(mul(A,B,C))
            printmat(C);
            else
            printf("unable to multiply due to defintion of matrix!\n");
        }
        else if(ch=='2')
        {
            if(add(A,B,C))
            printmat(C);
            else
            printf("unable to add since matrixs differ in size!\n");
        }
        else
        printf("Invalid input, try again!\n");
    }
    system("pause");
}
/*
2 2
1 2
2 1
2 2
1 1
1 1
*/
/*
3 3
1 0 2
0 0 3
4 0 0
3 3
0 1 2
3 0 0
0 2 2
*/