extern void inputdic(void);
extern void orderinput(void);
extern void foodmake(long ttime);
extern struct Time timereverse(long ttime);
extern void ordercpl(void);
struct food
{
    char name[100];
    long cap;
    long curcap;
    int maketime;
    int making;
    int rematime;
};
struct Time
{
    int hour;
    int minute;
    int second;
};
struct combo
{
    char name[100];
    int varnum;
    int comboindex[100];
};
struct order
{
    long stime;
    int finishstatus;
    long cpltime;
    int varn;
    int ingre[25];
};