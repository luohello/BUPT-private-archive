#include"OJhead.h"
void foodmake(long ttime)
{
    long interv = ttime - prevtime;
    for (long j = 0; j < interv; j++) // 相当于时间行进interv秒
        for (int i = 1; i <= foodnum; i++)
            if (!storage[i].making)
            {
                if (storage[i].curcap < storage[i].cap)
                {
                    storage[i].making = 1;
                    storage[i].rematime = storage[i].maketime - 1;
                }
            }
            else
            {
                if (storage[i].rematime == 1)
                {
                    storage[i].curcap++;
                    storage[i].making = 0;
                    storage[i].rematime = storage[i].maketime;
                }
                else
                {
                    storage[i].rematime--;
                }
            }
    prevtime = ttime;
}