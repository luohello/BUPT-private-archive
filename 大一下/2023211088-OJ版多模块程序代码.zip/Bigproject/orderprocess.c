#include"OJhead.h"
long ordercheck(long ttime)
{
    long cnt = 0;
    for(long i = lastorderptr; ordermag[i].stime < ttime; i++)
    {
        if(ordermag[i].cpltime < ttime)
        lastorderptr=i;
        else
        break;
    }
    for (long i = lastorderptr; ordermag[i].stime < ttime; i++)
    {
        if (ordermag[i].finishstatus == 1)
        {
            if (ordermag[i].cpltime > ttime)
            {
                cnt++;
            }
        }
    }
    return cnt;
}
    struct Time timereverse(long ttime)
{
    struct Time temp;
    temp.hour = ttime / 3600 + 7;
    ttime = ttime % 3600;
    temp.minute = ttime / 60;
    temp.second = ttime % 60;
    return temp;
}
void ordercpl(void)
{
    for (orderptr = 0; orderptr < ordernum; orderptr++)
    {
        long currenttime = ordermag[orderptr].stime;
        long timeconsum = 0;
        long pendingorder1 = 0;
        long pendingorder2 = 0;
        foodmake(currenttime);

        pendingorder1 = ordercheck(currenttime);
        pendingorder2 = ordercheck(currenttime - 1);
        if (pendingorder1 < W2 && pendingorder2 < W2 && systemstatus == 0 && currenttime <= 54001)
        {
            systemstatus = 1;
        } // 控制系统是否接受订单
        if (currenttime > 54001)
            systemstatus = 0;
        if (systemstatus) // 若上一秒就已经能开放了则能接受订单
        {
            for (int i = 0; i < ordermag[orderptr].varn; i++)
            {
                long findex = ordermag[orderptr].ingre[i]; // 推算订单完成时间
                if (storage[findex].curcap <= 0)
                {
                    long eachconsum = storage[findex].rematime + ((-storage[findex].curcap) * storage[findex].maketime);
                    timeconsum = eachconsum > timeconsum ? eachconsum : timeconsum;
                }
                storage[findex].curcap--;
            }
            ordermag[orderptr].finishstatus = 1; // 1代表完成，-1代表失败，0代表未开始
            ordermag[orderptr].cpltime = ordermag[orderptr].stime + timeconsum;
            struct Time buftime = timereverse(ordermag[orderptr].cpltime);
            printf("%02d:%02d:%02d\n", buftime.hour, buftime.minute, buftime.second);
        }
        else
        {
            puts("Fail");
        }
        if (pendingorder1 == W1 && timeconsum > 0)
            systemstatus = 0;
    }
}