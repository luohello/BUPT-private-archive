#ifndef OJhead
#define OJhead
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
extern int foodnum;
extern int combonum;
extern int W1;
extern int W2;
extern char nametem[100];
extern long ordernum;
extern long orderptr;
extern int systemstatus;
extern long lastorderptr;
extern long prevtime;
extern struct food storage[105];
extern struct combo combos[105];
extern struct order ordermag[55555];
struct food
{
    char name[100];
    long cap;
    long curcap;
    int maketime;
    int making;
    int rematime;
};
struct Time
{
    int hour;
    int minute;
    int second;
};
struct combo
{
    char name[100];
    int varnum;
    int comboindex[100];
};
struct order
{
    long stime;
    int finishstatus;
    long cpltime;
    int varn;
    int ingre[25];
};
extern void inputdic(void);
extern void orderinput(void);
extern void foodmake(long ttime);
extern struct Time timereverse(long ttime);
extern void ordercpl(void);
#endif