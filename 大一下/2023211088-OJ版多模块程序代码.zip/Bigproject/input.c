#include"OJhead.h"
long timeconvert(void)
{
    long temp, ttime = 0;
    long thour,tminute,tsec;
    scanf("%d:%d:%d",&thour,&tminute,&tsec);
    return ((thour-7)*3600+60*tminute+tsec);
}
void inputdic(void)
{
    FILE *fp;
    int i;
    fp = fopen("dict.dic", "r");
    fscanf(fp, "%d%d", &foodnum, &combonum);
    for (i = 1; i <= foodnum; i++)
    {
        fscanf(fp, "%s", storage[i].name);
    }
    for (i = 1; i <= foodnum; i++)
    {
        fscanf(fp, "%d", &storage[i].maketime);
    }
    for (i = 1; i <= foodnum; i++)
    {
        fscanf(fp, "%ld", &storage[i].cap);
        storage[i].curcap = 0;
        storage[i].making = 1;
        storage[i].rematime = storage[i].maketime;
    }
    fscanf(fp, "%d%d", &W1, &W2);
    for (i = 1; i <= combonum; i++)
    {
        char temp1, temp2[100];
        fscanf(fp, "%s", combos[i].name);
        combos[i].varnum = 0;
        while (fscanf(fp, "%c", &temp1) != EOF && temp1 != '\n')
        {
            fscanf(fp, "%s", temp2);
            for (int j = 1; j <= foodnum; j++)
                if (!strcmp(temp2, storage[j].name))
                {
                    combos[i].comboindex[combos[i].varnum++] = j;
                    break;
                }
        }
    } // 输入
    fclose(fp);
}
void orderinput(void)
{
    scanf("%ld", &ordernum);
    for (long i = 0; i < ordernum; i++)
    {
        ordermag[i].finishstatus = 0;
        ordermag[i].stime = timeconvert();
        ordermag[i].cpltime = 0;
        scanf("%s", nametem);
        int findfood = 0;
        for (long j = 1; j <= foodnum; j++)
            if (!strcmp(nametem, storage[j].name))
            {
                ordermag[i].varn = 1;
                ordermag[i].ingre[0] = j;
                findfood = 1;
                break;
            }

        if (!findfood)
            for (long j = 1; j <= combonum; j++)
                if (!strcmp(nametem, combos[j].name))
                {
                    ordermag[i].varn = combos[j].varnum;
                    for (int k = 0; k < combos[j].varnum; k++)
                        ordermag[i].ingre[k] = combos[j].comboindex[k];
                }
    }
}
