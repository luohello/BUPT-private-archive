#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"mainheader.h"
struct food storage[105];
struct combo combos[105];
struct order ordermag[55555];
int foodnum;
int combonum;
int W1;
int W2;
char nametem[100] = {0};
long ordernum;
long orderptr = 0;
int systemstatus = 1;
long lastorderptr = 0;
long prevtime = 0;
int main()
{
    inputdic();
    orderinput();
    ordercpl();
    system("pause");
}