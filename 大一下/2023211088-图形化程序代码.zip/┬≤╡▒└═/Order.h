#ifndef ORDER
#define ORDER
struct order {
    int index;
    long stime;
    int finishstatus;//�Ƿ����
    int repstatus;//ϵͳ�Ƿ�ɹ�����
    long cpltime;
    int varn;
    int ingre[105];
    int remaintime;//��ǰ������ʣʱ��
    int outputmark;
    int fulfilled;
};
extern void orderinput(int index);
extern void printorder(int optr);
extern void ordercpl(void);
extern void orderrep(void);
#endif
#ifndef OVERALL_VARIABLE
#define OVERALL_VARIABLE
extern int foodnum, combonum, W1, W2;
extern char nametem[55];
extern long ddtimer;
extern long ordernum;
extern long orderptr;
extern long uncplorder;
extern int systemstatus;
extern int orderInputptr;
extern struct food storage[105];
extern struct dict menu[205];
extern struct order ordermag[54010];
extern struct order pendingorder[10];
#endif
