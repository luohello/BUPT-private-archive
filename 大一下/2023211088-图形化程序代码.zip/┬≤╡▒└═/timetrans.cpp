#include<stdio.h>
#include<string.h>
#include<stdlib.h>
long timeconvert(void)
{
    long temp, ttime = 0;
    int d = 3600;
    for (int i = 0; i < 3; i++)
    {
        scanf("%d", &temp);
        ttime += temp * d;
        d = d / 60;
        getchar();
    }
    return (ttime - 3600 * 7);
}