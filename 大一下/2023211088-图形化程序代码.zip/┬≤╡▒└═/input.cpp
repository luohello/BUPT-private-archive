#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"dict.h"
#include"Order.h"
#include"time_trans.h"
#include"windows.h"
void inputdic(void)
{
    FILE* fp;
    int i;
    fp = fopen("dict.dic", "r");
    fscanf(fp, "%d%d", &foodnum, &combonum);
    for (i = 1; i <= foodnum; i++)
    {
        fscanf(fp, "%s", menu[i].name);
        menu[i].varnum = 1;
        menu[i].comboindex[0] = i;
    }
    for (i = 1; i <= foodnum; i++)
    {
        fscanf(fp, "%d", &storage[i].maketime);
    }
    for (i = 1; i <= foodnum; i++)
    {
        fscanf(fp, "%d", &storage[i].cap);
        storage[i].curcap = 0;
        storage[i].making = 0;
        storage[i].needed = 0;
        storage[i].rematime = storage[i].maketime;
    }
    fscanf(fp, "%d%d", &W1, &W2);
    for (; i <= combonum + foodnum; i++)
    {
        char temp1, temp2[55];
        menu[i].varnum = 0;
        fscanf(fp, "%s", menu[i].name);
        while (fscanf(fp, "%c", &temp1) != EOF && temp1 != '\n')
        {
            fscanf(fp, "%s", temp2);
            menu[i].varnum++;
            for (int j = 1; j <= foodnum; j++)
                if (!strcmp(temp2, menu[j].name))
                {
                    menu[i].comboindex[menu[i].varnum - 1] = j;
                    break;
                }
        }
    }//����
    fclose(fp);
}
void orderinput(int index)//6.10�޸�--��a��b����Խӣ��뵱ǰʱ��Խӣ���������ordermag����Խ�
{
    ordermag[orderInputptr].index = orderInputptr;
        ordermag[orderInputptr].finishstatus = 0;
        ordermag[orderInputptr].repstatus = 1;
        ordermag[orderInputptr].stime = ddtimer;//��������ʱ����ڵ�ǰʱ��
        ordermag[orderInputptr].remaintime = 0;
        ordermag[orderInputptr].outputmark = 0;//6/8/22:00:00����outputmark����
        ordermag[orderInputptr].fulfilled = 0;
        if (index <= 18)
            strcpy(nametem, a[index - 1].name.c_str());
        else
            strcpy(nametem, b[index - 19].name.c_str());
        for (long j = 1; j <= foodnum + combonum; j++)
            if (!strcmp(nametem, menu[j].name))
            {
                ordermag[orderInputptr].varn = menu[j].varnum;
                for (int k = 0; k < menu[j].varnum; k++)
                    ordermag[orderInputptr].ingre[k] = menu[j].comboindex[k];
                break;
            }
        orderInputptr++;
}