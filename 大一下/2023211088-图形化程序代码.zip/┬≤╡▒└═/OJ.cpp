/*��ͼƬδ����ȷ���أ�����windows.cpp383-387���޸�Ϊ����Եľ���·�������·��*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <easyx.h>
#include <conio.h>
#include <functional>
#include <string>
#include <vector>
#include <iostream>
#include <windows.h>
#include <time.h>
#include"dict.h"
#include"Order.h"
#include"foodmake.h"
#include"windows.h"
#include"windows.cpp"
using namespace std;
using std::to_wstring;
int foodnum, combonum, W1, W2;
char nametem[55];
long ddtimer = 1;
long orderptr = 0;
long uncplorder = 0;
int systemstatus = 1;
int orderInputptr = 0;
struct food storage[105];
struct dict menu[205];
struct order ordermag[54010];
struct order pendingorder[10];
ButtonInfo a[18] = {
    {"BigMac"}, {"Fries"}, {"Coke"}, {"McChicken"}, {"Sprite"},
    {"SpicyMcChicken"}, {"Fanta"}, {"McWings"}, {"Coca-Cola"},
    {"CaesarSalad"}, {"GrilledChickenPieces"}, {"Croutons"}, {"SpecialDressing"},
    {"IceCream"}, {"ChocolateSauce"}, {"CrushedNuts"}, {"MiniBurger"}, {"Juice"}
};
ButtonInfo b[7] = {
    {"BigMacCombo"}, {"McChickenCombo"}, {"SpicyMcChickenCombo"}, {"McWingsCombo"},
    {"CaesarSaladCombo"}, {"IceCreamCombo"}, {"LittleTreasureCombo"}
};

IMAGE backgroundImg;
IMAGE jpg1;
IMAGE jpg2;
IMAGE jpg3;
IMAGE jpg4;
int main()
{
    inputdic();
    FILE* fpo = fopen("orderoutput.txt", "w");
    fprintf(fpo, "�������\n");
    fclose(fpo);
    Widget widget(1500, 700);
    widget.init();
    widget.run();
    widget.close();
    return 0;
}