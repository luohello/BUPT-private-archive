#ifndef FOODMAKE
#define FOODMAKE
extern void foodmake(int interv);
#endif
