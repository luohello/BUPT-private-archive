#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"dict.h"
#include"Order.h"
void printorder(int optr)//���ܵ�ǰ����������λ��
{
    int temp, total;
    FILE* fpo = fopen("orderoutput.txt", "a");

    if (ordermag[optr].repstatus)
    {
        int d = 3600;
        total = ordermag[optr].cpltime;
        for (int j = 0; j < 2; j++, total %= d, d /= 60)
        {
            temp = total / d;
            if (temp >= 10)
                fprintf(fpo,"%d:", temp);
            else
                fprintf(fpo,"0%d:", temp);
        }
        temp = total / d;
        if (temp >= 10)
            fprintf(fpo,"%d\n", temp);
        else
            fprintf(fpo,"0%d\n", temp);
    }
    else
        fprintf(fpo,"Fail\n");
    fclose(fpo);
}

void ordercpl(void)//ÿ��ִ��һ�θú���
{
    long temptr, j, iffinish;
    while (ordermag[orderptr].finishstatus)
        orderptr++;//ʹorderptr�ӵ�һ��δ��ɶ�����ʼ����
    int pending = 0;
    for (temptr = orderptr; temptr < orderInputptr && ordermag[temptr].stime <= ddtimer; temptr++)
    {
        if (ordermag[temptr].stime == ddtimer && systemstatus == 0)
        {
            ordermag[temptr].repstatus = 0;
            ordermag[temptr].finishstatus = 1;
            printorder(temptr);
        }
        else if (!ordermag[temptr].finishstatus)
        {
            ordermag[temptr].remaintime = 0;
            for (j = 0, iffinish = 1; j < ordermag[temptr].varn; j++)
                if (ordermag[temptr].ingre[j])
                {
                    int findex = ordermag[temptr].ingre[j];

                    if (storage[findex].curcap)
                    {
                        storage[findex].curcap -= 1;
                        ordermag[temptr].ingre[j] = 0;//��ʾ�ѵõ���Ҫԭ����
                    }
                    else if (storage[findex].makeone)
                    {
                        storage[findex].makeone = 0;
                        ordermag[temptr].ingre[j] = 0;
                    }
                    else
                    {
                        if (!ordermag[temptr].fulfilled)
                        {
                            storage[findex].needed++;
                            ordermag[temptr].fulfilled = 1;
                        }
                        int remtime = storage[findex].rematime + (storage[findex].needed - 1) * storage[findex].maketime;
                        ordermag[temptr].remaintime = ordermag[temptr].remaintime < remtime ? remtime : ordermag[temptr].remaintime;
                        iffinish = 0;
                    }
                }
            if (!ordermag[temptr].outputmark)
            {
            
                ordermag[temptr].cpltime = ordermag[temptr].stime + ordermag[temptr].remaintime;
                ordermag[temptr].outputmark=1;
            }


            if (iffinish)
            {
                ordermag[temptr].finishstatus = 1;
                printorder(temptr);
            }
            else
            {
                ordermag[temptr].index = pending;
                pendingorder[pending++] = ordermag[temptr];
            }
        }
    }
}


void orderrep(void)
{
    long temptr=orderptr;
    for (temptr = orderptr, uncplorder = 0; temptr < orderInputptr && ordermag[temptr].stime <= ddtimer; temptr++)
        if (!ordermag[temptr].finishstatus)
        {
            uncplorder++;
        }
    if (uncplorder == W1 + 1 || ddtimer > 54001)
    {
        systemstatus = 0;
    }
    if (!systemstatus && uncplorder < W2 && ddtimer <= 54001)
    {
        systemstatus = 1;
    }
}