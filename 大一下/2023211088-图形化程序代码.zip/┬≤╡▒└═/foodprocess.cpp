#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"dict.h"
void foodmake(int interv)
{
    for(int j=1;j<=interv;j++)
    for (int i = 1; i <= foodnum; i++)
        if (!storage[i].making)
        {
            if (storage[i].curcap < storage[i].cap)
            {
                storage[i].making = 1;
                storage[i].rematime = storage[i].maketime - 1;
            }
        }
        else
        {
            if (storage[i].rematime == 1)
            {
                if (storage[i].needed)
                {
                    storage[i].needed--;
                    storage[i].makeone = 1;
                }
                else
                storage[i].curcap++;
                storage[i].making = 0;
                storage[i].rematime = storage[i].making;
            }
            else
            {
                storage[i].rematime--;
            }
        }
}