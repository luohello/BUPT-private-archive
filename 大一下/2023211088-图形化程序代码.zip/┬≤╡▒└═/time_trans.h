#ifndef TIMETR
#define TIMETR
extern long timeconvert(void);
#endif
