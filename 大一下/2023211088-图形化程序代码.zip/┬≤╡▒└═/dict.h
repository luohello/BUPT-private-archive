#include"Order.h"
#ifndef DICT
#define DICT
struct dict {
	char name[55];
	int varnum;
	int comboindex[105];
};
struct food {
    long cap;
    long curcap;
    int maketime;
    int making;
    int rematime;
    int needed;
    int makeone;
};
extern void inputdic(void);
#endif
#ifndef OVERALL_VARIABLE
#define OVERALL_VARIABLE
extern int foodnum, combonum, W1, W2;
extern char nametem[55];
extern long ddtimer;
extern long ordernum;
extern long orderptr;
extern long uncplorder;
extern int systemstatus;
extern int orderInputptr;
extern struct food storage[105];
extern struct dict menu[205];
extern struct order ordermag[54010];
extern struct order pendingorder[10];
#endif